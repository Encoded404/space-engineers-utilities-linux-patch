from enum import Enum

class ToolType(Enum):
    Fbximporter = 1
    Havok = 2
    MWMBuilder = 3
